package com.my.maybank.customer.dao;

import java.util.List;

import com.my.maybank.customer.dto.CustomerDTO;
import com.my.maybank.customer.entity.Customer;
import com.my.maybank.customer.exception.PortalCoreException;

public interface CustomerDao {

	void save(List<CustomerDTO> customerDTOList);
	
	void updateDescription(String id, String description, String updatedBy) throws PortalCoreException;
	
	Customer findById(String id) throws PortalCoreException;
	
	List<CustomerDTO> getCustomerDetailsList(String searchBy, String searchValue, Integer pageNo,
			Integer pageSize)  throws PortalCoreException;
}
