package com.my.maybank.customer.services;

import java.util.List;

import com.my.maybank.customer.dto.CustomerDTO;
import com.my.maybank.customer.exception.PortalCoreException;

public interface CustomerService {

	void extractCustomerFlatFile();

	void updateDescription(String id, String description, String updatedBy) throws PortalCoreException;

	List<CustomerDTO> getCustomerDetailsList(String searchBy, String searchValue, Integer pageNo, Integer pageSize)
			throws PortalCoreException;
}
