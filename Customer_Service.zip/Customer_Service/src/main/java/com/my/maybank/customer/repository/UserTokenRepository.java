package com.my.maybank.customer.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.my.maybank.customer.entity.UserToken;

@Repository
public interface UserTokenRepository extends CrudRepository<UserToken, Long> {

	@Query("SELECT t FROM UserToken t WHERE t.token = ?1 AND t.is_valid = 1")
	Optional<UserToken> findByToken(String token);

	@Query("SELECT t FROM UserToken t WHERE t.id = ?1 AND t.is_valid = 1")
	Optional<UserToken> findById(String id);
}
