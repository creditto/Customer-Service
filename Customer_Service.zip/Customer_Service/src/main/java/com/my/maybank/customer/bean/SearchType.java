package com.my.maybank.customer.bean;

public enum SearchType {

	CUSTOMER_ID, ACCOUNT_NUMBER, DESCRIPTION;
}
