package com.my.maybank.customer.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.persistence.*;
import javax.validation.constraints.Size;

@Entity
@Table(name = "USER_TOKEN ", uniqueConstraints = { @UniqueConstraint(columnNames = "token") })
public class UserToken {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String id;

	@Size(max = 20)
	private String username;

	@Size(max = 1)
	private String is_valid;

	@Size(max = 500)
	private String token;

	@Column(name = "DATE_CREATED")
	private LocalDateTime dateCreated;
	
	@Column(name = "DATE_INVALIDATED")
	private LocalDateTime dateInvalidate;

	public UserToken() {
	}

	public UserToken(String userName, String token) {
		this.id = UUID.randomUUID().toString();
		this.token = token;
		this.is_valid = "1";
		this.dateCreated = LocalDateTime.now();

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIs_valid() {
		return is_valid;
	}

	public void setIs_valid(String is_valid) {
		this.is_valid = is_valid;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public LocalDateTime getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDateTime dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDateTime getDateInvalidate() {
		return dateInvalidate;
	}

	public void setDateInvalidate(LocalDateTime dateInvalidate) {
		this.dateInvalidate = dateInvalidate;
	}

}
