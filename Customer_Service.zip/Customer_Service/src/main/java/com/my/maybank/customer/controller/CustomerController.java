package com.my.maybank.customer.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.my.maybank.customer.dto.CustomerDTO;
import com.my.maybank.customer.exception.PortalCoreException;
import com.my.maybank.customer.services.CustomerService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@CrossOrigin()
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@ApiOperation("Update the description")
	@ApiResponses(@ApiResponse(code = 200, message = "Description updateed successfully"))
	@PostMapping("/updateDescription")
	public ResponseEntity<String> updateDescription(@RequestParam(name = "id" , required = true) String id,
			@RequestParam(name = "description" , required = true) String description, @RequestHeader("name") String name)
			throws PortalCoreException {

		if (StringUtils.isNotBlank(id) && StringUtils.isNotBlank(description) && StringUtils.isNotBlank(name)) {
			customerService.updateDescription(id, description, name);
			return ResponseEntity.ok("Description successfully updated");
		} else {
			throw new PortalCoreException("E03", "Input Params is not empty");
		}
	}

	@ApiOperation("Retrieve the customer transaction details")
	@ApiResponses(@ApiResponse(code = 200, message = "Retrieve the customer details"))
	@PostMapping("/retrieveTxn")
	public ResponseEntity<List<CustomerDTO>> retrieveTxnDetails(
			@RequestParam(name = "searchType", required = true) String searchType,
			@RequestParam(name = "searchValue", required = true) String searchValue,
			@RequestParam(defaultValue = "0", required = true) Integer pageNo,
			@RequestParam(defaultValue = "10", required = true) Integer pageSize) throws PortalCoreException {

		
		if (StringUtils.isNotBlank(searchType) && StringUtils.isNotBlank(searchValue) && pageNo != null
				&& pageSize != null) {
			return ResponseEntity.ok(customerService.getCustomerDetailsList(searchType, searchValue, pageNo, pageSize));
		} else {
			throw new PortalCoreException("E03", "Input Params is not empty");
		}
	}
}
